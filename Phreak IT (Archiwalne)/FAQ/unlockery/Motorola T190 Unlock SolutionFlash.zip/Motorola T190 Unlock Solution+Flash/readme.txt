Unlock T190 ML1576, ML1583
1. First start DMTools
2. Load Flash file: New Partial unlock T190.mot
3. Press download
4. Press power on
5. The phone will have beep sound and can't power on (Totally Dead :-)))
6. Load flash file:  ML153930.mot and change data base to ML153930.bin
7. Press download again and power on the phone.
8. reset eeprom and unlock with old version T19x unlocker
9. Ur Phone unlocked :-))

Hope u enjoy it.

